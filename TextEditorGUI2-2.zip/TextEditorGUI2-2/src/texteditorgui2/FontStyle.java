/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package texteditorgui2;

/**
 *
 * @author dylanmora
 */
public class FontStyle extends TextEditorGUI {
    private String fontName;
    private int fontStyle;
    private int fontSize;

    public FontStyle(String fontName, int fontStyle, int fontSize) {
        this.fontName = fontName;
        this.fontStyle = fontStyle;
        this.fontSize = fontSize;
    }
    
    public String getFontName(){
    return "";
    }
    
    public int fontStyle(){
    return 0;
    }
    
    public int fontSize(){
    return 0;
    }
    
    
    
}
